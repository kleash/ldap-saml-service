# ldap-saml-service
Single service to authenticate user via LDAP or SAML
